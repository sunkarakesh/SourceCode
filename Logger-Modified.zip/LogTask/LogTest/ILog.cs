﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace LogTest
{
    public interface ILog
    {
        /// <summary>
        /// Stop the component. 
        /// </summary>
        void StopComponent(CancellationToken ct);

        /// <summary>
        /// Write a message to the Log.
        /// </summary>
        /// <param name="text">The text to written to the log</param>
        void Write(string text);

    }
}
