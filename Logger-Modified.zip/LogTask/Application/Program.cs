﻿using LogTest;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LogUsers
{
    class Program
    {
        public static async Task Main()
        {
            string dirPath = string.Format($"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\\LogTest");
            if (!Directory.Exists(dirPath))
                Directory.CreateDirectory(dirPath);
            DateTime datetime = DateTime.Now;
            string fileName = $"Log-{datetime.ToString("yyyyMMdd HHmmss fff")}.log";
            string strPath = Path.Combine(dirPath, fileName);
            StringBuilder sb = new StringBuilder();
            sb.Append("Timestamp".PadRight(25, ' '));
            sb.Append("\t");
            sb.Append("Data".PadRight(15, ' '));
            sb.Append("\t");
            sb.Append(Environment.NewLine);

            Console.WriteLine("Press any key to begin tasks...");
            Console.ReadKey(true);

            var tokenSource = new CancellationTokenSource();
            CancellationToken ct = tokenSource.Token;

            LogMessage message1 = new LogMessage();
            message1.LogDate = datetime;
            message1.LogHeader = sb.ToString();
            message1.LogPath = strPath;
            message1.LogInfo = "Number with Flush";

            AsyncLog logger1 = new AsyncLog(message1);
            var tokenSource1 = new CancellationTokenSource();
            CancellationToken ct1 = tokenSource1.Token;
            try
            {
                Console.WriteLine("To terminate the Logfile-1, press 'c' to cancel and exit...");
                Console.WriteLine();
                Task listOfTasks = Task.Run(() => logger1.WriteToLogFile(message1, Enumerable.Range(0, 15), ct1), ct1);
                if (listOfTasks.Status != TaskStatus.RanToCompletion)
                {
                    char ch = Console.ReadKey().KeyChar;
                    if (ch == 'c' || ch == 'C')
                    {
                        tokenSource1.Cancel();
                        Console.WriteLine("\nStopping the component, outstanding logs are not written");
                        logger1.StopComponent(ct1);
                    }
                }
                await listOfTasks;
                Console.WriteLine("\nFinished writing all the Logfile-1");
            }
            catch (OperationCanceledException e)
            {
                //If needed we can track log here
                //Console.WriteLine($"{nameof(OperationCanceledException)} thrown with message: {e.Message}");
            }
            finally
            {
                tokenSource1.Dispose();
                Console.WriteLine("\nPress enter to continue ");
                Console.ReadLine();
            }


            Console.WriteLine("*************************************************************************");

            datetime = DateTime.Now;
            fileName = $"Log-{datetime.ToString("yyyyMMdd HHmmss fff")}.log";
            strPath = Path.Combine(dirPath, fileName);

            LogMessage message2 = new LogMessage();
            message2.LogDate = datetime;
            message2.LogHeader = sb.ToString();
            message2.LogPath = strPath;
            message2.LogInfo = "Number with No flush";
            var tokenSource2 = new CancellationTokenSource();
            CancellationToken ct2 = tokenSource2.Token;
            
            AsyncLog logger2 = new AsyncLog(message2);
            try
            {
                Console.WriteLine("To terminate the Logfile-2, press 'c' to cancel and exit...");
                Console.WriteLine();

                Task listOfTasks = Task.Run(() => logger2.WriteToLogFile(message2, Enumerable.Range(0, 50).OrderByDescending(x => x), ct2), ct2);
                if (listOfTasks.Status != TaskStatus.RanToCompletion)
                {
                    char ch = Console.ReadKey().KeyChar;
                    if (ch == 'c' || ch == 'C')
                    {
                        Console.WriteLine("\nComponent will be stopped after all outstanding logs written");
                    }
                }
                await listOfTasks;
                Console.WriteLine("\nFinished writing all the Logfile-2");
                if (listOfTasks.Status == TaskStatus.RanToCompletion)
                {
                    logger2.StopComponent(ct2);
                }
            }
            catch (OperationCanceledException e)
            {
                //If needed we can track log here
                //Console.WriteLine($"{nameof(OperationCanceledException)} thrown with message: {e.Message}");
            }
            finally
            {
                tokenSource2.Dispose();
                Console.WriteLine("\nPress enter to exit ");
                Console.ReadLine();
            }

        }

    }
}
