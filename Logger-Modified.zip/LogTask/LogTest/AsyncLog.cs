﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LogTest
{
    public class LogMessage
    {
        public string LogPath { get; set; }
        public string LogHeader { get; set; }
        public string LogInfo { get; set; }
        public DateTime LogDate { get; set; }
    }
    public class AsyncLog : ILog
    {
        private string FilePath = string.Empty;
        public AsyncLog(LogMessage log)
        {
            using (StreamWriter outputFile = new StreamWriter(log.LogPath))
            {
                outputFile.WriteLine(log.LogHeader);
            }
        }

        public void StopComponent(CancellationToken ct)
        {
            if (ct.IsCancellationRequested)
            {
                // Clean up here, then...
                ct.ThrowIfCancellationRequested();
            }
        }

        public List<Task> WriteToLogFile(LogMessage logMessage, IEnumerable<int> collection, CancellationToken ct)
        {
            List<Task> listOfTasks = new List<Task>();
            string strLog = logMessage.LogInfo;
            foreach (int ivalue in collection)
            {
                logMessage.LogInfo = $"{strLog}: {ivalue}";
                listOfTasks.Add(DoAsync(JsonConvert.SerializeObject(logMessage), ct));
            }
            return listOfTasks;
        }

        private Task DoAsync(string json, CancellationToken ct)
        {
            //cacel requested
            if (ct.IsCancellationRequested)
            {
                ct.ThrowIfCancellationRequested();
            }
            //Doing some work
            SpinWait spinWait = new SpinWait();
            for (int j = 0; j <= 200; j++)
            {
                spinWait.SpinOnce();
            }
            lock (this)
            {
                Write(json);
            }
            return Task.CompletedTask;
        }


        public void Write(string content)
        {
            LogMessage dLogMsg = JsonConvert.DeserializeObject<LogMessage>(content);
            try
            {
                if (null != dLogMsg)
                {
                    DateTime datetime = DateTime.Now;
                    bool bDateChanged = datetime.DayOfWeek == dLogMsg.LogDate.DayOfWeek ? false : true;
                    bool bHeaderCheck = false;
                    if (bDateChanged && string.IsNullOrEmpty(FilePath))
                    {
                        string[] path = dLogMsg.LogPath.Split('\\');
                        if (null != path && path.Length > 0 && string.IsNullOrEmpty(FilePath))
                        {
                            path[Array.FindIndex(path, row => row.Contains(".log"))] = $"Log-{datetime.ToString("yyyyMMdd HHmmss fff")}.log";
                            dLogMsg.LogPath = string.Join("\\", path);
                            FilePath = dLogMsg.LogPath;
                            bHeaderCheck = true;
                        }
                    }
                    string strfilepath = string.IsNullOrEmpty(FilePath) ? dLogMsg.LogPath : FilePath;
                    using (StreamWriter outputFile = new StreamWriter(strfilepath, true))
                    {
                        StringBuilder stringBuilder = new StringBuilder();
                        if (bHeaderCheck)
                        {
                            outputFile.WriteLineAsync(dLogMsg.LogHeader);
                        }
                        stringBuilder.Append(datetime.ToString("yyyy-MM-dd HH:mm:ss:fff"));
                        stringBuilder.Append("\t");
                        stringBuilder.Append(dLogMsg.LogInfo);
                        stringBuilder.Append("\t");
                        stringBuilder.Append(Environment.NewLine);
                        outputFile.WriteLineAsync(stringBuilder.ToString());
                        Console.WriteLine(dLogMsg.LogInfo);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"{nameof(Exception)} thrown with message: {e.Message}");
            }
        }
    }
}