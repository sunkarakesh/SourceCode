﻿using LogTest;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace UnitTest
{
    [TestClass]
    public class LogFileUnitTest
    {

        //This test case if to check if the logs are written to log
        [TestMethod]
        public void TestMethod1()
        {
            string dirPath = string.Format($"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\\LogUnitTest");
            if (!Directory.Exists(dirPath))
                Directory.CreateDirectory(dirPath);
            DateTime datetime = DateTime.Now;
            string fileName = $"Log-{datetime.ToString("yyyyMMdd HHmmss fff")}.log";
            string strPath = Path.Combine(dirPath, fileName);
            StringBuilder sb = new StringBuilder();
            sb.Append("Timestamp".PadRight(25, ' '));
            sb.Append("\t");
            sb.Append("Data".PadRight(15, ' '));
            sb.Append("\t");
            sb.Append(Environment.NewLine);
            var tokenSource1 = new CancellationTokenSource();
            CancellationToken ct1 = tokenSource1.Token;
            LogMessage message1 = new LogMessage();
            message1.LogDate = DateTime.Now;
            message1.LogHeader = sb.ToString();
            message1.LogPath = strPath;
            message1.LogInfo = "UnitTest Case-1";

            AsyncLog log1 = new AsyncLog(message1);
            Task.Run(() => log1.WriteToLogFile(message1, Enumerable.Range(0, 5), ct1), ct1).Wait();
            tokenSource1.Dispose();
            string[] lines = System.IO.File.ReadAllLines(strPath);
            Assert.AreEqual(true, lines.Length > 5 ? true : false);

        }


        //This test case to stop the component in the middle and outstanding logs will not be written
        [TestMethod]
        public void TestMethod2()
        {
            string dirPath = string.Format($"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\\LogUnitTest");
            if (!Directory.Exists(dirPath))
                Directory.CreateDirectory(dirPath);
            DateTime datetime = DateTime.Now;
            string fileName = $"Log-{datetime.ToString("yyyyMMdd HHmmss fff")}.log";
            string strPath = Path.Combine(dirPath, fileName);
            StringBuilder sb = new StringBuilder();
            sb.Append("Timestamp".PadRight(25, ' '));
            sb.Append("\t");
            sb.Append("Data".PadRight(15, ' '));
            sb.Append("\t");
            sb.Append(Environment.NewLine);
            LogMessage message = new LogMessage();
            message.LogDate = DateTime.Now;
            message.LogHeader = sb.ToString();
            message.LogPath = strPath;
            message.LogInfo = "UnitTest Case-2";

            AsyncLog log = new AsyncLog(message);
            var tokenSource = new CancellationTokenSource();
            CancellationToken ct = tokenSource.Token;
            Task.Run(() => log.WriteToLogFile(message, Enumerable.Range(0, 10), ct), ct)
                    .Wait(1000, ct);
            try
            {
                tokenSource.Cancel();
                log.StopComponent(ct);
            }
            catch
            {
            }
            finally
            {
                tokenSource.Dispose();
            }
            string[] lines = File.ReadAllLines(strPath);
            Assert.AreEqual(true, lines.Length > 0 ? true : false);
        }

        //This test case to wait till all the logs files are written to log file
        [TestMethod]
        public void TestMethod3()
        {
            string dirPath = string.Format($"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\\LogUnitTest");
            if (!Directory.Exists(dirPath))
                Directory.CreateDirectory(dirPath);
            DateTime datetime = DateTime.Now;
            string fileName = $"Log-{datetime.ToString("yyyyMMdd HHmmss fff")}.log";
            string strPath = Path.Combine(dirPath, fileName);
            StringBuilder sb = new StringBuilder();
            sb.Append("Timestamp".PadRight(25, ' '));
            sb.Append("\t");
            sb.Append("Data".PadRight(15, ' '));
            sb.Append("\t");
            sb.Append(Environment.NewLine);
            LogMessage message = new LogMessage();
            message.LogDate = DateTime.Now;
            message.LogHeader = sb.ToString();
            message.LogPath = strPath;
            message.LogInfo = "UnitTest Case-3";

            AsyncLog log = new AsyncLog(message);
            var tokenSource = new CancellationTokenSource();
            CancellationToken ct = tokenSource.Token;
            Task.Run(() => log.WriteToLogFile(message, Enumerable.Range(0, 10), ct), ct)
                    .Wait();
            log.StopComponent(ct);
            tokenSource.Dispose();
            string[] lines = File.ReadAllLines(strPath);
            Assert.AreEqual(true, lines.Length > 10 ? true : false);
        }

        //This test case to check if the business day changes then write to new log file
        [TestMethod]
        public void TestMethod4()
        {
            string dirPath = string.Format($"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\\LogUnitTest");
            
            DateTime datetime = DateTime.Now;
            string fileName = $"Log-{datetime.ToString("yyyyMMdd HHmmss fff")}.log";
            string strPath = Path.Combine(dirPath, fileName);
            StringBuilder sb = new StringBuilder();
            sb.Append("Timestamp".PadRight(25, ' '));
            sb.Append("\t");
            sb.Append("Data".PadRight(15, ' '));
            sb.Append("\t");
            sb.Append(Environment.NewLine);
            LogMessage message = new LogMessage();
            message.LogDate = datetime;
            message.LogHeader = sb.ToString();
            message.LogPath = strPath;
            message.LogInfo = "UnitTest Case-4";

            AsyncLog log = new AsyncLog(message);
            var tokenSource = new CancellationTokenSource();
            CancellationToken ct = tokenSource.Token;
            message.LogDate = datetime.AddDays(1);  // Added extra day to change the business day
            Task.Run(() => log.WriteToLogFile(message, Enumerable.Range(0, 10), ct), ct)
                    .Wait();
            log.StopComponent(ct);
            string[] lines = File.ReadAllLines(strPath);
            Assert.AreEqual(true, lines.Length > 0 ? true : false);
        }
    }
}
